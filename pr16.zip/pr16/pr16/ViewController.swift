//
//  ViewController.swift
//  pr16
//
//  Created by Дмитрий Лазарев on 03/06/2021.
//  Copyright © 2021 Дмитрий Лазарев. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

